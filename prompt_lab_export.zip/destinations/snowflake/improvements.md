# Changelog: Technology Snowflake (snowflake)

## Version 1
- Current engine configuration exported.
- Optimize the 'config' object for better engine interpretation.
