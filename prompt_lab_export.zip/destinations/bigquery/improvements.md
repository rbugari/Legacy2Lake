# Changelog: Technology Google BigQuery (bigquery)

## Version 1
- Current engine configuration exported.
- Optimize the 'config' object for better engine interpretation.
