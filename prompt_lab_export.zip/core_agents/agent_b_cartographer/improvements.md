# Changelog: Agent B - Cartographer

## Version 1
- Initial version exported from the engine.
- Use this space to document improvements for Version 2.
