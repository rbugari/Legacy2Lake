# Changelog: Technology Microsoft SQL Server (sqlserver)

## Version 1
- Current engine configuration exported.
- Optimize the 'config' object for better engine interpretation.
